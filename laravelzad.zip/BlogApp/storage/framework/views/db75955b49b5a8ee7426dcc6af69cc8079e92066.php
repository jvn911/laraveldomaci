<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('update_blog_path',['blog'=> $blog->id])); ?>" method="POST">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<div class="form-group">
<label for="title">Naziv</label>
<input type="text" name="title" class="form-control" value="<?php echo e($blog->title); ?>">
</div>

<div class="form-group">
<label for="content">Recept</label>
<textarea name="content" rows="10" class="form-control"><?php echo e($blog->content); ?></textarea>
</div>
<br>
<div class="form-group">
<button type="submit" class="btn btn-outline-primary">Edituj Baby Mule koktel</button>
</div>
</form> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dragan\BlogApp\resources\views/blogs/edit.blade.php ENDPATH**/ ?>