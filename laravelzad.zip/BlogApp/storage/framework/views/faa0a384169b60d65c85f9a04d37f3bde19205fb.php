<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('store_blog_path')); ?>" method="POST" enctype="multipart/form-data">

<?php echo csrf_field(); ?>

<div class="form-group">
<label for="title">Naziv</label>
<input type="text" name="title" class="form-control">
</div>

<div class="form-group">
<label for="content">Recept</label>
<textarea name="content" rows="10" class="form-control"></textarea>
</div>

<br>

<div class="form-group">
<input type="file" name="images" class="form-control">
</div>

<br>

<div class="form-group">
<button type="submit" class="btn btn-outline-primary">Dodaj Baby Mule koktel</button>
</div>
</form> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dragan\BlogApp\resources\views/blogs/create.blade.php ENDPATH**/ ?>