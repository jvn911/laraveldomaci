<?php $__env->startSection('content'); ?>
<div class="row">

<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="col-md-6">
<br>
<br>
<div class="card">

<div class="card-header">

<a href="<?php echo e(route('blog_path', ['blog'=>$blog->id])); ?>"><?php echo e($blog->title); ?></a>


</div>

<div class="card-body">
<a href="<?php echo e(route('blog_path', ['blog'=>$blog->id])); ?>">
<img src="<?php echo e(asset($blog->image)); ?>" alt="" class="card-img-top">
</a>

<br>
<br>

<p class="lead">
objavljeno

<?php echo e($blog->created_at->diffForHumans()); ?>

</p>

<a href="<?php echo e(route('blog_path', ['blog'=>$blog->id])); ?>" class="btn btn-outline-primary">Pogledaj recept</a>


</div>

</div>


</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dragan\BlogApp\resources\views/blogs/index.blade.php ENDPATH**/ ?>