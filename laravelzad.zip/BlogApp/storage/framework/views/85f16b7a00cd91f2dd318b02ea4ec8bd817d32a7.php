<?php $__env->startSection('content'); ?>

<div class="row">

<div class="col-md-12">
<br>
<img src="<?php echo e(asset($blog->image)); ?>" class="card-img-top">
<br>
<br>
<h3><?php echo e($blog->title); ?></h3>
<br>
<p class="lead">
<?php echo e($blog->content); ?>

</p>


<a href="<?php echo e(route('edit_blog_path',['blog'=>$blog->id])); ?>" class="btn btn-outline-info">Edit</a>
<a href="<?php echo e(route('blogs_path')); ?>" class="btn btn-outline-secondary">Nazad</a>
<form action="<?php echo e(route('delete_blog_path',['blog'=>$blog->id])); ?>" method="POST">
<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>
<br>
<button type="submit" class="btn btn-outline-danger">Obriši</button>
</form>

</div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dragan\BlogApp\resources\views/blogs/show.blade.php ENDPATH**/ ?>